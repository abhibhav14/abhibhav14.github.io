import numpy as np
import math
import itertools

class Agent:

    '''
    class variables:
    name
    maxHealth
    currentHealth
    armour

    statusList

    '''

    classStatusList = ["weak", "vuln", "frail", "str"]

    def __init__(self, name, maxHealth, deck):
        self.name = name
        self.maxHealth = maxHealth
        self.currentHealth = maxHealth
        self.deck = deck

        self.armour = 0

        self.turnCount = 1

        self.env = None

        self.statusList = dict()
        for i in Agent.classStatusList:
            self.statusList[i] = 0

    def takeDamage(self, damage, physical=True):
        total = damage
        if physical and (self.statusList["vuln"] > 0):
            total = total * 1.5
        
        if self.armour > total:
            self.armour = self.armour - total
            self.armour = int(self.armour)
            return

        total = total - self.armour 
        self.currentHealth = self.currentHealth - total
        self.currentHealth = int(self.currentHealth)
        self.armour = 0
        return

    def incomingDamage(self, damage):
        total = damage
        if self.statusList["vuln"] > 0:
            total = total * 1.5
        if self.armour > total:
            return 0
        return total - self.armour

    def dealDamage(self, damage, physical=True):
        if not physical:
            return damage

        d = damage
        d += self.statusList["str"]
        if physical and (self.statusList["weak"] > 0):
            d = d * 0.75
        return int(d)

    def gainArmour(self, a):
        self.armour += a
        return

    def takeStatus(self, status, count):
        self.statusList[status] += count
        return

    def setEnv(self, e):
        self.env = e

    def agentEndTurn(self):
        self.armour = 0
        if self.statusList["weak"] > 0:
            self.statusList["weak"] -= 1
        if self.statusList["frail"] > 0:
            self.statusList["frail"] -= 1
        if self.statusList["vuln"] > 0:
            self.statusList["vuln"] -= 1

    def allowedMoves(self, hand):
        zeroCost = list()
        remaining = list()
        orderCards = list()
        for i, j in zip(hand, range(len(hand))):
            if i.energy == 0:
                zeroCost.append(j)
            else:
                remaining.append(j)
            if i.order:
                orderCards.append(j)
        c = itertools.combinations(remaining, 3)
        valid = list()
        validCardSort = list()
        for i in c:
            if sum([hand[j].energy for j in i]) <= 3:
                if any([hand[j].order for j in i]):
                    allPerms = itertools.permutations(i)
                    for k in allPerms:
                        nameArray = [hand[j].name for j in k]
                        oArray = [hand[j].order for j in k]
                        sig = list()
                        t = list()
                        for j in range(len(nameArray)):
                            if oArray[j]:
                                if j > 0:
                                    sig.append(sorted(t))
                                    t = list()
                                sig.append([nameArray[j]])
                            else:
                                t.append(nameArray[j])
                        if len(t) > 0:
                            sig.append(sorted(t))
                        if sig not in validCardSort:
                            valid.append(k)
                            validCardSort.append(sig)
                elif sorted([hand[j].name for j in i]) not in validCardSort:
                    valid.append(i)
                    validCardSort.append(sorted([hand[j].name for j in i]))
        moves = [list(i) + zeroCost for i in valid]
        return moves


class Manual(Agent):

    def __init__(self, name, maxHealth, deck):
        super(Manual, self).__init__(name, maxHealth, deck)

    def pickCards(self, en, e, d):
        i =  input()
        nums = map(int, i.split())
        seen = set()
        return [x for x in nums if not (x in seen or seen.add(x))]

class RandomCards(Agent):
    def __init__(self, name, maxHealth, deck):
        super(RandomCards, self).__init__(name, maxHealth, deck)

    def pickCards(self, en, e, d):
        return np.random.permutation(np.arange(5))

class BasicHeuristic(Agent):
    def __init__(self, name, maxHealth, deck, heuristic):
        super(BasicHeuristic, self).__init__(name, maxHealth, deck)
        self.heuristic = heuristic

    def pickCards(self, en, e, d):
        incoming = d
        hand = en.hand
        blockCards = list()
        remaining = list()
        for i, j in zip(hand, range(len(hand))):
            if i.block > 0:
                blockCards.append([i.block, j])
            else:
                remaining.append([i.damage, j])
        blockCards.sort()
        remaining.sort()
        order = list()
        #todo: deal with frail here
        if self.heuristic == "safe":
            for i in blockCards:
                if incoming <= 0:
                    break
                order.append(i[1])
                incoming -= i[0]
            for i in remaining:
                order.append(i[1])
        elif self.heuristic == "smorc":
            for i in remaining:
                order.append(i[1])
            for i in blockCards:
                order.append(i[1])
        else:
            for i in blockCards:
                if incoming < i[0]:
                    break
                order.append(i[1])
                incoming -= i[0]
            for i in remaining:
                order.append(i[1])
        return order

class FlatMC(Agent):
    def __init__(self, name, maxHealth, deck, limit=50):
        super(FlatMC, self).__init__(name, maxHealth, deck)
        self.limit = limit

    def pickCards(self, en, e, d):
        incoming = d
        hand = en.hand
        moves = self.allowedMoves(hand)
        bestMove = 0
        bestWins = 0
        bestHP = 0
        simulationsPerAction = int(self.limit / len(moves)) + 1
        for (i, j) in zip(moves, range(len(moves))):
            w, l, rh = en.simulations(simulationsPerAction, i)
            if (w > bestWins) or ((w == bestWins) and (rh > bestHP)):
                bestMove = j
                bestWins = w
                bestHP = rh
        return moves[bestMove]

class FlatUCB(Agent):
    def __init__(self, name, maxHealth, deck, limit=50, tradeOff = 0.414):
        super(FlatUCB, self).__init__(name, maxHealth, deck)
        self.limit = limit
        self.tradeOff = tradeOff

    def pickCards(self, en, e, d):
        incoming = d
        hand = en.hand
        moves = self.allowedMoves(hand)
        m = len(moves)
        moveHp = [0 for i in range(m)]
        moveCount = [0 for i in range(m)]
        simulationsPerAction = int(self.limit / len(moves)) + 1
        for (i, j) in zip(moves, range(m)):
            w, l, rh = en.simulations(1, i)
            moveCount[j] += 1
            moveHp[j] += (rh / self.currentHealth)
        for i in range(self.limit):
            lnm = math.log(i + m)
            uctVals = np.array([(moveHp[i] / moveCount[i]) + 2 * self.tradeOff * math.sqrt(2 * lnm / moveCount[i]) for i in range(m)])
            arm = np.random.choice(np.where(uctVals == uctVals.max())[0])
            w, l, rh = en.simulations(1, moves[arm])
            moveCount[arm] += 1
            moveHp[arm] += (rh / self.currentHealth)
        return moves[np.argmax(np.array([(moveHp[i] / moveCount[i]) for i in range(m)]))]


class Tree:

    def __init__(self, moves, nextDraw, nextEnemyMove, nextStatuses, nextDrawNameSorted, terminalHp=-1, heuristic=None):

        self.stateCount = 0

        self.moves = moves[:]
        self.numChildren = len(self.moves)

        self.childNodes = [list() for i in range(self.numChildren)]
        self.childCounts = np.array([0 for i in range(self.numChildren)])
        self.unexplored = True
        self.childHP = np.array([0.0 for i in range(self.numChildren)])

        self.enemyMove = nextEnemyMove
        if nextStatuses is not None:
            self.nextStatuses = nextStatuses[:]
        else:
            self.nextStatuses = None
        if nextDraw is not None:
            self.nextDraw = nextDraw[:]
        else:
            self.nextDraw = None
        self.nextDrawNameSorted = nextDrawNameSorted
        self.terminalHp = terminalHp

        if heuristic is None:
            self.heuristic = lambda x, y, z: 0
        else:
            self.heuristic = heuristic


    def getRandomUnexplored(self):
        return np.random.choice(np.where(self.childCounts == 0)[0])
    
    def getUCB(self, tradeOff=0.414):
        uctVals = (self.childHP / self.childCounts) + 2 * tradeOff * np.sqrt(2 * math.log(self.stateCount) / self.childCounts)
        return np.random.choice(np.where(uctVals == uctVals.max())[0])

    def getProgBias(self, enemy, tradeOff=0.414, heuristicTradeOff=1.0):
        uctVals = (self.childHP / self.childCounts) + 2 * tradeOff * np.sqrt(2 * math.log(self.stateCount) / self.childCounts)
        for i in range(len(uctVals)):
            uctVals[i] += heuristicTradeOff * (self.heuristic(i, self, enemy) / self.childCounts[i])
        return np.random.choice(np.where(uctVals == uctVals.max())[0])

    def UCTVal(self, tradeOff=0.414):
        uctVals = self.childHP / self.childCounts + 2 * tradeOff * np.sqrt(2 * math.log(self.stateCount) / self.childCounts)
        return uctVals

    def progBias(self, enemy, tradeOff=0.414, heuristicTradeOff=1.0):
        uctVals = (self.childHP / self.childCounts) + 2 * tradeOff * np.sqrt(2 * math.log(self.stateCount) / self.childCounts)
        for i in range(len(uctVals)):
            uctVals[i] += heuristicTradeOff * (self.heuristic(i, self, enemy) / self.childCounts[i])
        return uctVals

    def checkChild(self, a, nextDraw, nextEnemyMove, nextStatuses):
        nameList = [i.name for i in nextDraw]
        it = iter(nameList)
        sizes = [5 for i in range(int(len(nameList) / 5))]
        sizes.append(len(nameList) % 5)
        splitNameListSorted = [sorted([next(it) for _ in range(size)]) for size in sizes]
        for (c, j) in zip(self.childNodes[a], range(len(self.childNodes[a]))):
            if c.enemyMove != nextEnemyMove:
                continue
            if c.nextStatuses != nextStatuses:
                continue
            if splitNameListSorted != c.nextDrawNameSorted:
                continue
            return j, None
        return -1, splitNameListSorted

    def updateExplored(self):
        if len(np.where(self.childCounts == 0)[0]) == 0:
            self.unexplored = False

    def findTerminal(self, a, hp):
        for (c, j) in zip(self.childNodes[a], range(len(self.childNodes[a]))):
            if c.terminalHp == hp:
                return j
        return -1

    def sampleState(self, a):
        r = np.random.choice(self.childNodes[a])
        terminal = (r.terminalHp >= 0)
        return (terminal, r.terminalHp, r.nextDraw, r.enemyMove, r.nextStatuses)

class UCT(Agent):
    def __init__(self, name, maxHealth, deck, limit=50, tradeOff = 0.414, depth=3, width=-1, heuristic=None, simPerIter=10):

        super(UCT, self).__init__(name, maxHealth, deck)
        self.limit = limit
        self.tradeOff = tradeOff
        self.depth = depth
        self.width = width
        self.heuristic = heuristic
        self.simPerIter = 10

    def pickCards(self, en, e, d):

        hand = en.hand
        incoming = d
        moves = self.allowedMoves(hand)

        # initialise the tree
        tree = Tree(self.allowedMoves(hand), None, None, None, None, heuristic=self.heuristic)
        for s in range(int(self.limit / self.simPerIter)):
            curr = tree
            # first step is the tree search phase
            actions = list()
            actionIndex = list()
            resultIndex = list()
            terminal = False
            r = 0
            size=0
            for d in range(self.depth - 1):
                if curr.unexplored:
                    # there is an action in the current node, so we must node expand
                    a = curr.getRandomUnexplored()
                else:
                    a = curr.getUCB(self.tradeOff)
                    # a = curr.getProgBias(enemy = e, tradeOff=self.tradeOff)

                actions.append([curr.moves[a], None, None])
                actionIndex.append(a)
                if (self.width != -1) and (len(curr.childNodes[a]) >= self.width):
                    # sample from the seen stuff
                    (terminal, result, nextDraw, nextEnemyMove, nextStatuses) = curr.sampleState(a)
                else:
                    (terminal, result, nextDraw, nextEnemyMove, nextStatuses) = en.nextState(actions)

                if terminal:
                    # here we stop iteration and just backprop
                    # we still want a child node for the sake of widths, so we make a None tree node
                    b = curr.findTerminal(a, result)
                    if b == -1:
                        # add a terminal node
                        t = Tree(list(), None, None, None, None, terminalHp=result, heuristic=self.heuristic)
                        curr.childNodes[a].append(t)
                    resultIndex.append(None)
                    r = result
                    break

                actions[d][1] = nextEnemyMove
                actions[d][2] = nextDraw[:]
                b, s = curr.checkChild(a, nextDraw, nextEnemyMove, nextStatuses)
                if b == -1:
                    # new tree
                    t = Tree(self.allowedMoves(nextDraw[0:5]), nextDraw, nextEnemyMove, nextStatuses, s, heuristic=self.heuristic)
                    curr.childNodes[a].append(t)
                    resultIndex.append(len(curr.childNodes[a]) - 1)
                    curr = t
                else:
                    curr = curr.childNodes[a][b]
                    resultIndex.append(b)

            if not terminal:
                # pick action for the leaf node
                if curr.unexplored:
                    # there is an action in the current node, so we must node expand
                    a = curr.getRandomUnexplored()
                else:
                    a = curr.getUCB(self.tradeOff)
                    # a = curr.getProgBias(enemy = e, tradeOff=self.tradeOff)
                actions.append([curr.moves[a], None, None])
                actionIndex.append(a)
                resultIndex.append(None)

                # now the simulation
                w, l, r = en.simulationWithFixedActions(self.simPerIter, actions, False)

            # backprop
            curr = tree
            for d in range(len(actionIndex)):
                curr.stateCount = curr.stateCount + 1
                curr.childCounts[actionIndex[d]] += 1
                curr.childHP[actionIndex[d]] += (r / self.currentHealth)
                curr.updateExplored()
                if resultIndex[d] is not None:
                    curr = curr.childNodes[actionIndex[d]][resultIndex[d]]
                else:
                    break

        return tree.moves[tree.getUCB(tradeOff=0.0)]

def dontBlockHeuristic(m, t, e):
    if t.enemyMove is None:
        return 0
    incoming = e.moveList[t.enemyMove].damage
    if incoming > 0:
        return 0
    else:
        block = sum([t.nextDraw[i].block for i in t.moves[m]])
        if block > 0:
            return 0
        return 1

def dontOverBlockHeuristic(m, t, e):
    if t.enemyMove is None:
        return 0
    incoming = e.moveList[t.enemyMove].damage
    block = sum([t.nextDraw[i].block for i in t.moves[m]])
    if block > incoming:
        return 1
    else:
        return 0
