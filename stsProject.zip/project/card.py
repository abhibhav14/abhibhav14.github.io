import numpy as np
from copy import deepcopy

class Card:

    def __init__(self, name, operator, index, cost, damage=0, block=0, order=False):

        self.name = name
        self.operator = operator
        self.cardIndex = index
        self.energy = cost
        # damage or block, for computation by AI
        self.damage = damage
        self.block = block
        # whether it matters what order the card is played in, for example cards that apply vuln
        self.order=order

# Below is a library of cards

def cardDoNothing(a, e):
    return

def cardDealDamage(n):
    def f(a, e):
        d = a.dealDamage(n)
        e.takeDamage(d)
        return
    return f

def cardBlock(n):
    def f(a, e):
        a.gainArmour(n)
        return
    return f

def cardApplyEnemyStatus(w=0, v=0, p=0, s=0):
    def f(a, e):
        e.takeStatus("weak", w)
        e.takeStatus("vuln", v)
        e.takeStatus("poison", p)
        e.takeStatus("str", s)
        return
    return f

def cardApplyEnemyStatusAndDamage(w=0, v=0, p=0, s=0, d=0, b=0):
    def f(a, e):
        e.takeStatus("weak", w)
        e.takeStatus("vuln", v)
        e.takeStatus("poison", p)
        e.takeStatus("str", s)
        da = a.dealDamage(d)
        e.takeDamage(da)
        a.gainArmour(b)
        return
    return f

def cardApplyAgentStatus(s):
    def f(a, e):
        a.takeStatus("str", s)
        return
    return f

strike = Card("Strike", cardDealDamage(6), 0, 1, damage=6)
defend = Card("Defend", cardBlock(5), 0, 1, block=5)
survivor = Card("Survivor", cardBlock(8), 0, 1, block=8)
neut = Card("Neutralise", cardApplyEnemyStatusAndDamage(w=1, d=3), 0, 0)
pstab = Card("Pstab", cardApplyEnemyStatusAndDamage(p=3, d=6), 0, 1, damage=13)
dp = Card("Deadly Poison", cardApplyEnemyStatus(p=5), 0, 1, damage=13)
s = Card("Wave", cardApplyEnemyStatus(w=5, v=5), 0, 1, order=True)
inflame = Card("Inflame", cardApplyAgentStatus(s=3), 0, 1, order=True)
sweep = Card("Leg Sweep", cardApplyEnemyStatusAndDamage(w=2, b=4), 0, 1, order=False, block=4)
bash = Card("Bash", cardApplyEnemyStatusAndDamage(v=2, d=5), 0, 1, damage=8, order=True)

def silentStarter():
    d = [deepcopy(strike) for i in range(5)]
    for i in range(5):
        d.append(deepcopy(defend))
    d.append(survivor)
    d.append(neut)
    return d

def silentFightThree():
    d = [deepcopy(strike) for i in range(5)]
    for i in range(5):
        d.append(deepcopy(defend))
    d.append(survivor)
    d.append(neut)
    d.append(pstab)
    d.append(dp)
    return d

def silentInflame():
    d = [deepcopy(strike) for i in range(5)]
    for i in range(5):
        d.append(deepcopy(defend))
    d.append(survivor)
    d.append(neut)
    d.append(inflame)
    return d

def silentLateDeck():
    d = [deepcopy(strike) for i in range(3)]
    for i in range(4):
        d.append(deepcopy(defend))
    d.append(survivor)
    d.append(neut)
    d.append(inflame)
    d.append(bash)
    d.append(sweep)
    d.append(pstab)
    return d
