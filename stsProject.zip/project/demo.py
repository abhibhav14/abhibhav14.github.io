import numpy as np
from copy import deepcopy
from enemy import *
from agent import *
from card import *
from env import *

verbose = True

d = silentStarter()

player = UCT("Abhi", 60, d, limit=100, depth=2, heuristic=None, width=5)
# player = FlatUCB("Abhi", 60, d, limit=500)
# player = FlatMC("Abhi", 60, d, limit=100)
# player = BasicHeuristic("Abhi", 60, d, heuristic="smorc")
# player = RandomCards("Abhi", 60, d)
# player = Manual("Abhi", 60, d)
jawWorm = newJawWorm()

e = Fight(player, jawWorm)
f, r = e.normalTurn(verbose)
while not f:
    f, r = e.normalTurn(verbose)

if f == 1:
    print(f"{player.name} defeated {jawWorm.name} with {r} health remaining :)")
else:
    print(f"{player.name} lost to {jawWorm.name} :(")
