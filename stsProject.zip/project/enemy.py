import numpy as np

class Enemy:

    '''
    class variables:
    name
    maxHealth
    currentHealth
    armour

    turnCount
    moveHistory
    moveTable
    statusList

    '''

    classStatusList = ["weak", "vuln", "poison", "str"]

    def __init__(self, name, maxHealth, moveList, firstMove=None):
        self.name = name
        self.maxHealth = maxHealth
        self.currentHealth = maxHealth
        self.armour = 0

        self.currentMove = None
        self.turnCount = 1
        self.moveHistory = list()
        self.moveList = moveList
        self.lastMove = None
        self.lastMoveCount = 0

        self.statusList = dict()
        for i in Enemy.classStatusList:
            self.statusList[i] = 0

        if firstMove is None:
            self.decideNextMove()
        else:
            self.fixGivenMove(firstMove)

    def takeDamage(self, damage, physical=True):
        total = damage
        if physical and (self.statusList["vuln"] > 0):
            total = total * 1.5
        
        if self.armour > total:
            self.armour = self.armour - total
            self.armour = int(self.armour)
            return

        total = total - self.armour 
        self.currentHealth = self.currentHealth - total
        self.currentHealth = int(self.currentHealth)
        self.armour = 0
        return

    def incomingDamage(self, damage):
        total = damage
        if self.statusList["vuln"] > 0:
            total = total * 1.5
        if self.armour > total:
            return 0
        return total - self.armour
    
    def dealDamage(self, damage, physical=True):
        if not physical:
            return damage

        d = damage
        d += self.statusList["str"]
        if physical and (self.statusList["weak"] > 0):
            d = d * 0.75
        return int(d)

    def gainArmour(self, a):
        self.armour += a
        return

    def takeStatus(self, status, count):
        self.statusList[status] += count
        return

    def showIntent(self):
        return self.moveList[self.currentMove], self.dealDamage(self.moveList[self.currentMove].damage)

    def decideNextMove(self):
        possibleMoves = list()
        for i in range(len(self.moveList)):
            if i != self.lastMove:
                possibleMoves.append(i)
            else:
                if self.lastMoveCount < self.moveList[i].maxTurns:
                    possibleMoves.append(i)

        probabilities = np.array([self.moveList[i].probability for i in possibleMoves])
        probabilities = probabilities / sum(probabilities)

        move = np.random.choice(possibleMoves, p = probabilities)
        if self.lastMove == move:
            self.lastMoveCount += 1
        else:
            self.lastMove = move
            self.lastMoveCount = 1

        self.currentMove = self.lastMove
        return self.moveList[move]

    def fixGivenMove(self, m):
        move = m
        if self.lastMove == move:
            self.lastMoveCount += 1
        else:
            self.lastMove = move
            self.lastMoveCount = 1

        self.currentMove = self.lastMove
        return self.moveList[move]

    def agentEndTurn(self):
        self.armour = 0
        if self.statusList["poison"] > 0:
            self.takeDamage(self.statusList["poison"], physical=False)
            self.statusList["poison"] -= 1

        return

    def enemyEndTurn(self):
        if self.statusList["weak"] > 0:
            self.statusList["weak"] -= 1
        if self.statusList["vuln"] > 0:
            self.statusList["vuln"] -= 1
        self.decideNextMove()
        return

class EnemyMove:

    def __init__(self, name, operator, probability, maxTurns, damage):

        self.name = name
        self.operator = operator
        self.probability = probability
        self.maxTurns = maxTurns
        self.damage = damage

# Library of moves
def doNothing(a, e):
    return

def enemyDealDamage(n):
    def f(a, e):
        d = e.dealDamage(n)
        a.takeDamage(d)
        return
    return f

def enemyBlock(n):
    def f(a, e):
        e.gainArmour(n)
        return
    return f

def applyAgentStatus(w=0, v=0, f=0, s=0):
    def f(a, e):
        a.takeStatus("weak", w)
        a.takeStatus("vuln", v)
        a.takeStatus("frail", p)
        a.takeStatus("str", s)
        return
    return f

def applyEnemyStatus(s):
    def f(a, e):
        e.takeStatus("str", s)
        return
    return f

def jawTrash(a, e):
    d = e.dealDamage(7)
    a.takeDamage(d)
    e.gainArmour(5)
    return

def jawTrashScary(a, e):
    d = e.dealDamage(12)
    a.takeDamage(d)
    e.gainArmour(5)
    return

def jawBellow(a, e):
    e.takeStatus("str", 5)
    e.gainArmour(9)
    return

def jawBellowScary(a, e):
    e.takeStatus("str", 10)
    e.gainArmour(12)
    return

def cultistRitual(a, e):
    return

def cultistAttack(a, e):
    d = e.dealDamage(7)
    a.takeDamage(d)
    e.takeStatus("str", 8)
    return

def newJawWorm(hp=46):
    a1 = EnemyMove("Chomp", enemyDealDamage(12), .25, 1, 12)
    a2 = EnemyMove("Thrash", jawTrash, .3, 2, 7)
    a3 = EnemyMove("Bellow", jawBellow, .45, 1, 0)
    l = [a1, a2, a3]
    jawWorm = Enemy("Jaw Worm", hp, l, firstMove=0)
    return jawWorm

def scaryJawWorm(hp=106):
    a1 = EnemyMove("Chomp", enemyDealDamage(17), .25, 1, 17)
    a2 = EnemyMove("Thrash", jawTrashScary, .3, 2, 12)
    a3 = EnemyMove("Bellow", jawBellowScary, .45, 1, 0)
    l = [a1, a2, a3]
    jawWorm = Enemy("Jaw Worm", hp, l, firstMove=0)
    return jawWorm

def newCultist(hp=56):
    a1 = EnemyMove("Ritual", cultistRitual, 0, 1, 0)
    a2 = EnemyMove("Dark Strike", cultistAttack, 1, 100000, 6)
    l = [a1, a2]
    cultist = Enemy("Cultist", hp, l, firstMove=0)
    return cultist

def newSnakePlant(hp=100):
    a1 = EnemyMove("Chomp", enemyDealDamage(20), 1, 1, 15)
    a2 = EnemyMove("Spore", doNothing, 1, 1, 0)
    l = [a1, a2]
    cultist = Enemy("Cultist", hp, l, firstMove=0)
    return cultist
