import numpy as np
import time
from enemy import *
from card import *
from agent import *
from copy import deepcopy

class Fight:

    def __init__(self, agent, enemy):

        self.agent = agent
        self.enemy = enemy

        self.deck = agent.deck
        self.drawPile = list()
        self.discardPile = list()
        self.hand = list()

        self.drawPile = self.deck[:]
        np.random.shuffle(self.drawPile)

        self.hand = self.drawPile[0:5]
        self.drawPile = self.drawPile[5:]

        self.turnCount = 1

    def agentChoice(self, d):
        a = self.agent.pickCards(self, self.enemy, d)
        return a

    def performTurn(self, a, e, randomAction=False, particularAction=None, particularEnemyAction=None, particularShuffle=None, verbose=False):


        mIndex = e.currentMove
        m = e.moveList[mIndex]
        d = 0
        if m.damage > 0:
            d = e.dealDamage(m.damage)
            d = a.incomingDamage(d)

        if verbose:
            print()
            print(f"Agent Hp: {a.currentHealth}")
            print(f"Enemy Hp: {e.currentHealth}({e.armour})")
            print(f"Enemy Attack: {m.name}")
            print(f"Enemy Damage: {d}")
            print()
            print(f"Cards in hand:")
            for i in self.hand:
                print(f"{i.name}")
            print()

        if randomAction:
            cardsPlayed = np.random.permutation(np.arange(5))
        elif particularAction is not None:
            cardsPlayed = particularAction
        else:
            cardsPlayed = self.agentChoice(d)
        energy = 3
        for i in cardsPlayed:
            cost = self.hand[i].energy
            if (energy - cost) >= 0:
                if verbose:
                    print(f"Playing {self.hand[i].name}")
                self.hand[i].operator(a, e)
                energy = energy - cost

        if e.currentHealth <= 0:
            return 1, a.currentHealth

        e.agentEndTurn()

        if e.currentHealth <= 0:
            return 1, a.currentHealth

        m.operator(a, e)

        if a.currentHealth <= 0:
            return -1, 0

        self.discardPile[:] = self.discardPile[:] + self.hand[:]

        if len(self.drawPile) > 4:
            self.hand = self.drawPile[0:5]
            self.drawPile = self.drawPile[5:]
        else:
            if particularShuffle is None:
                np.random.shuffle(self.discardPile)
            else:
                self.discardPile = particularShuffle[:]
            self.drawPile[:] = self.drawPile[:] + self.discardPile[:]
            self.discardPile = list()
            self.hand = self.drawPile[0:5]
            self.drawPile = self.drawPile[5:]

        e.enemyEndTurn()
        a.agentEndTurn()

        if particularEnemyAction is not None:
            e.fixGivenMove(particularEnemyAction)

        return 0, a.currentHealth
    
    def normalTurn(self, verbose=False):
        return self.performTurn(self.agent, self.enemy, verbose=verbose)

    def simulations(self, numSimulations, action, verbose=False):
        # create copies of everything
        drawPileCopy = self.drawPile[:]
        handCopy = self.hand[:]
        discardPileCopy = self.discardPile[:]

        wins = 0
        loss = 0
        remainingHp = 0

        for i in range(numSimulations):
            agentCopy = deepcopy(self.agent)
            enemyCopy = deepcopy(self.enemy)

            v, r = self.performTurn(agentCopy, enemyCopy, particularAction=action, verbose=verbose)
            while v == 0:
                v, r = self.performTurn(agentCopy, enemyCopy, randomAction=True, verbose=verbose)

            if v == 1:
                wins += 1
                remainingHp += r
            else:
                loss += 1
            self.drawPile = drawPileCopy[:]
            self.hand = handCopy[:]
            self.discardPile = discardPileCopy[:]

        return wins, loss, remainingHp / numSimulations
    
    def nextState(self, actions, verbose=False):
        drawPileCopy = self.drawPile[:]
        handCopy = self.hand[:]
        discardPileCopy = self.discardPile[:]

        agentCopy = deepcopy(self.agent)
        enemyCopy = deepcopy(self.enemy)

        v = 0
        for (agentAction, enemyAction, shuffle) in actions:
            v, r = self.performTurn(agentCopy, enemyCopy, particularAction=agentAction, particularEnemyAction=enemyAction, particularShuffle=shuffle, verbose=verbose)
            if v != 0:
                self.drawPile = drawPileCopy[:]
                self.hand = handCopy[:]
                self.discardPile = discardPileCopy[:]
                return True, r, None, None, None
        nextDraw = self.hand[:] + self.drawPile[:]
        self.drawPile = drawPileCopy[:]
        self.hand = handCopy[:]
        self.discardPile = discardPileCopy[:]
        return False, 0, nextDraw, enemyCopy.currentMove, str(agentCopy.statusList) + str(enemyCopy.statusList)
    
    def simulationWithFixedActions(self, numSimulations, actions, verbose=False):

        drawPileCopy = self.drawPile[:]
        handCopy = self.hand[:]
        discardPileCopy = self.discardPile[:]

        agentCopy = deepcopy(self.agent)
        enemyCopy = deepcopy(self.enemy)

        v = 0
        for (agentAction, enemyAction, shuffle) in actions:
            v, r = self.performTurn(agentCopy, enemyCopy, particularAction=agentAction, particularEnemyAction=enemyAction, particularShuffle=shuffle, verbose=verbose)
            if v == 1:
                self.drawPile = drawPileCopy[:]
                self.hand = handCopy[:]
                self.discardPile = discardPileCopy[:]
                return 1, 0, agentCopy.currentHealth
            elif v == -1:
                self.drawPile = drawPileCopy[:]
                self.hand = handCopy[:]
                self.discardPile = discardPileCopy[:]
                return 0, 1, 0

        drawPileSimCopy = self.drawPile[:]
        handSimCopy = self.hand[:]
        discardPileSimCopy = self.discardPile[:]

        wins = 0
        loss = 0
        remainingHp = 0

        for i in range(numSimulations):
            agentRandomCopy = deepcopy(agentCopy)
            enemyRandomCopy = deepcopy(enemyCopy)
            v = 0
            while v == 0:
                v, r = self.performTurn(agentRandomCopy, enemyRandomCopy, randomAction=True, verbose=verbose)
            if v == 1:
                wins += 1
                remainingHp += r
            else:
                loss += 1
            self.drawPile = drawPileSimCopy[:]
            self.hand = handSimCopy[:]
            self.discardPile = discardPileSimCopy[:]

        self.drawPile = drawPileCopy[:]
        self.hand = handCopy[:]
        self.discardPile = discardPileCopy[:]

        return wins, loss, remainingHp / numSimulations

