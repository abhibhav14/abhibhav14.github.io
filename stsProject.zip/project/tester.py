import numpy as np
from copy import deepcopy
from enemy import *
from agent import *
from card import *
from env import *
import scipy.stats

remainingHp = list()
winCount = 0
verbose = True
numExp = 1
d = silentStarter()

def mean_confidence_interval(data, confidence=0.95):
    a = 1.0 * np.array(data)
    n = len(a)
    m, se = np.mean(a), scipy.stats.sem(a)
    h = se * scipy.stats.t.ppf((1 + confidence) / 2., n-1)
    return m-h, m, m+h, h

for i in range(numExp):
    if (i % 10) == 0:
        print(i)
    # abhi = UCT("Abhi", 60, d, limit=500, depth=2, heuristic=dontOverBlockHeuristic)
    # abhi = UCT("Abhi", 60, d, limit=500, depth=3, heuristic=None, width=5)
    # abhi = FlatUCB("Abhi", 60, d, limit=500)
    # abhi = FlatMC("Abhi", 60, d, limit=100)
    # abhi = BasicHeuristic("Abhi", 60, d, heuristic="smorc")
    # abhi = RandomCards("Abhi", 60, d)
    abhi = Manual("Abhi", 60, d)
    jawWorm = newSnakePlant()
    # jawWorm = newCultist()
    e = Fight(abhi, jawWorm)
    f, r = e.normalTurn(verbose)
    while not f:
        f, r = e.normalTurn(verbose)
    if f == 1:
        winCount += 1
    remainingHp.append(r)

print("total deaths:", numExp - winCount)
print(mean_confidence_interval(remainingHp))
